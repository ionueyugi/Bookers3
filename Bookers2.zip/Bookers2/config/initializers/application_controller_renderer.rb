# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '157f23122e4039a26e48a0d4f223d3f902a99d71d5636a9eebf955dcc4430b861740158c028f8b264ce94a574bfa75df3826ffa4b7dbdefdb0423e63a23c40f6'

