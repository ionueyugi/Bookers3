class UsersController < ApplicationController
      before_action :authenticate_user!
  def index
  	  @users = User.all
  	  @book = Book.new
      @bookuser = @book.user
  end

  def show
      @user = User.find(params[:id])
      @books = @user.books.all
  	  @book = Book.new
  	  

  end

  def create
  	  @user = User.new(user_params)
  	  if @user.save
  	  	flash[:notice] = "successfully"

  	  redirect_to user_path(@user.id)
  	  else
  	  	@users = User.all
  	  	render action: :index
  	  end
  end

  def edit
  	 @user = User.find(params[:id])
  end

  def update
  	  @user = User.find(params[:id])
  	  if @user.update(user_params)
  	     flash[:notice] = "successfully"
  	     redirect_to user_path(@user.id)
      else
        render action: :show
      end
  end

  def destroy
  	  user = User.find(params[:id])
  	  user.destroy
  	  redirect_to books_path
  end

  def new
  end

  private
  def user_params
  	params.require(:user).permit(:name, :introduction, :profile_image)
  end
end
